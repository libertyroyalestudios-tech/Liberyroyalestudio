
// Portfolio upload preview
document.addEventListener('DOMContentLoaded', function(){
  const upload = document.getElementById('upload');
  const grid = document.getElementById('grid');
  const clearBtn = document.getElementById('clear');
  if(upload){
    upload.addEventListener('change', function(e){
      const files = Array.from(e.target.files);
      files.forEach(file => {
        const reader = new FileReader();
        reader.onload = function(ev){
          const div = document.createElement('div');
          div.className = 'portfolio-card';
          const img = document.createElement('img');
          img.src = ev.target.result;
          img.alt = file.name;
          div.appendChild(img);
          grid.prepend(div);
        }
        reader.readAsDataURL(file);
      });
    });
  }
  if(clearBtn){
    clearBtn.addEventListener('click', function(){
      // remove all custom uploaded images keeping three samples
      const cards = grid.querySelectorAll('.portfolio-card');
      cards.forEach((c, idx) => {
        if(idx < 3) return; // keep first three sample cards
        c.remove();
      });
    });
  }

  // contact form placeholder behavior
  const form = document.getElementById('contactForm');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      alert('Thanks! Your message is noted (this is a demo).');
      form.reset();
    });
  }
});

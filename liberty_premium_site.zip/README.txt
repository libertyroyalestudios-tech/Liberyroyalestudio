
Liberty Royale Studio - Premium Static Site (ready to preview)

How to preview:
1. Unzip this folder.
2. Open index.html in your browser (double-click).

How to publish for FREE (super simple steps):
Option A - GitHub Pages (easy):
1. Go to github.com and sign up (free).
2. Create a new repository (public) and upload all files here (drag & drop).
3. Go to repository -> Settings -> Pages. Choose 'main' branch and root folder. Save.
4. After a minute, your site will be live at https://YOURUSERNAME.github.io/REPO-NAME/

Option B - Netlify (drag & drop):
1. Go to netlify.com and sign up (free).
2. From the app, choose Deploy -> Drag & Drop and drop the whole folder (or the zip's contents).
3. Netlify will give you a free website link instantly.

If you want a React or Vite source project instead, reply and I will generate that zip.
